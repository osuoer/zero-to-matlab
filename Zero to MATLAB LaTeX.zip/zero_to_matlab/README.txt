This directory contains the LaTeX files for Zero to MATLAB.

The content folder contains the main.tex file as well as all output files. It also contains a style file, mcode.sty, which is used for formatting MATLAB syntax in the document.

Inside the content folder is a folder for the chapters. Each chapter is contained within a labeled subfolder.

Inside each chapter folder is a .tex file with content, as well as folders for images (img) and scripts (m_files) that are used in the document.
