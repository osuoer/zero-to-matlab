% fit data with polynomial
close all; clear all;

% make some noisy data
n_pts = 20;
x = linspace(0,pi,n_pts);
y = sin(x) + 0.1*randn(1,n_pts);

% fit the polynomial
p = polyfit(x,y,3);


% x1 = linspace(0,pi/2);
y_fit = polyval(p,x);


plot(x,y,'o')
hold on
plot(x,y_fit)
% hold off



