% fit data with polynomial
close all; clear all;

% make some noisy data
n_pts = 20;
x = linspace(0,10,n_pts);
y = 0.25*x + 0.2*randn(1,n_pts);

% fit the polynomial
p = polyfit(x,y,1);

% calcuate best fit line
y_fit = polyval(p,x);

% plot data and
% best fit line
plot(x,y,'o')
hold on
plot(x,y_fit,'-')

% format plot
axis([-0.5,11,-0.5,3.5])
title('Curve Fitting')
ylabel('y-axis')
xlabel('x-axis')
legend('Data','Best Fit')



