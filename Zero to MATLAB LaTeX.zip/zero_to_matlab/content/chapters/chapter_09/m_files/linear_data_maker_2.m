%-------------------------------------------------------
% linear_data_maker.m
%-------------------------------------------------------
% Description

%   This script generates some noisy data with a linear
%   trend. The purpose is to generate a data set to test
%   the least squares linear regression algorithm .

%-------------------------------------------------------
% Built-In Functions Required

%  length()  - Calculates the length of an array.

%  linspace()  - Creates an array of linear data points.

%  randn()  - Creates an array of normally distributed
%             random numbers.

%  plot()  - Creates a plot of points defined by arrays.

%  axis()  - Scales teh axis on the current plot.

%  max()  - Finds the amximum value in an array.

%  min()  - Finds the minimum value in an array.

%  title() - Sets the title for the active plot.

%  xlabel() - Sets the label for the x-axis for the active plot.

%  ylabel() - Sets the label for the y-axis for the active plot.

%-------------------------------------------------------
% preamble
clear all; close all; clc; format compact;

% define number of points
num_pts = 50;

% create independent variable with linspace
x = linspace(0,10,num_pts);

% use linspace and randn to generate noisy data
y = linspace(2,7,num_pts) + randn(1,num_pts);

% plot the data with blue cross markers
plot(x,y,'b+')
hold on

% scale the axes based on min/max values for easy viewing
padding = 0.2;
axis([min(x)-padding*max(x) (1 + padding)*max(x) min(y)-padding*max(y) (1+padding)*max(y)])

% title and label
% title('Noisy Data with a Linear Trend')
xlabel('Independent Variable (Some Units)')
ylabel('Dependent Variable (Some Units)')

% clean up the workspace
clearvars -except x y