%-------------------------------------------------------
% least_squares.m
%-------------------------------------------------------

%  This script calculates the slope and
%  intercept of a linear data estimator
%  via least squares linear regression.

%-------------------------------------------------------
% Bulit-In Functions Required

%  length()  - Calculates the length of an array.

%  plot()  - Creates a plot of points defined by arrays.
%-------------------------------------------------------

% calculate x average
x_tot = 0;
for i = 1:length(x)
    x_tot = x_tot + x(i);
end
x_bar = x_tot/length(x);

% calculate y average
y_tot = 0;
for j = 1:length(y)
    y_tot = y_tot + y(j);
end
y_bar = y_tot/length(y);

% calculate sums
top_sum = 0;
bottom_sum = 0;
for k = 1:length(x)
    x_err = x(k) - x_bar;
    y_err = y(k) - y_bar;
    x_err_square = (x_err)^2;

    top_sum = top_sum + (x_err*y_err);
    bottom_sum = bottom_sum + x_err_square;
end

% calculate M
M = top_sum/bottom_sum;

% calculate B
B = y_bar - M*x_bar;

% calculate endpoints for best fit line
x1 = 0;
x2 = 10;
y1 = M*x1 + B;
y2 = M*x2 + B;

% plot the line
plot([x1,x2],[y1,y2], 'r-')
