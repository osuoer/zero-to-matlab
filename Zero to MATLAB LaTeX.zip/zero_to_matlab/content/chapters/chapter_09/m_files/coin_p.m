% function p = coin_p(n_flips)

n_flips = 100;
n_heads = 0;

for i = 1:n_flips
    
    flip = round(rand(1));
    
    if flip == 1
        n_heads = n_heads + 1;
    end

    
end
p = n_heads/n_flips;

fprintf('The probability of getting heads in the coin flip is: %.2f \n',p)

% end