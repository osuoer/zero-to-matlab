% coin_flip_trials.m
% This script simulates a 
% batch of trials using the 
% heads_streak function.
clear all; close all; clc;

% number of flips
n_flips = 200;

% number of trials
n_trials = 1000;

% loop through trials 
for i = 1:n_trials
    max_heads(i) = heads_streak(n_flips);
end

% plot the histogram
histogram(max_heads)
tit = sprintf('%d Trials of %d Flips',n_trials,n_flips)
title(tit,'FontSize',15)
ylabel('Number of Trials')
xlabel('Max Consecutive Heads')