clear all;
close all;

x = [-2:0.5:2];

y = x.^3 - 2*x;

% x = 0;
% y = 0;

plot(x,y)
hold on
plot(x,y,'ro')
axis([-2 2 -4 4])
xL = xlim; 
yL = ylim; 
line(xL, [0 0],'color','k','linewidth',1) %x-axis 
line([0 0], yL,'color','k','linewidth',1) %y-axis
grid on

xlabel('x-axis')
ylabel('y-axis')