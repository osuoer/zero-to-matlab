% box_counter.m
%
% This script calculates the maximum number of boxes
% that can be stacked inside a storage area.
%
% The problem statement is given
% in Chapter 3 of Zero to MATLAB.

% Clear Workspace and Command Window.
clear all;
clc;


% Define the storage area dimensions.

% length (ft)
storage_length = 20;

% width (ft)
storage_width = 8;

% height (ft)
storage_height = 10;


% Define the box dimensions.

% length (in)
box_length = 32.5*b;

% width (in)
box_width = 32.5;

% height (in)
box_height = 28.5;


% Calculate n_long

% convert inches to feet
box_length = box_length/12;

% calculate boxes along dimension in decimal form
n_long = storage_length/box_length;

% round down to integer
n_long = floor(n_long);

% Calculate n_wide

% convert inches to feet
box_width = box_width/12;

% calculate boxes along dimension in decimal form
n_wide = storage_width/box_width;

% round down to integer
n_wide = floor(n_wide);

%Calculate n_high

% convert inches to feet
box_height = box_height/12;

% calculate boxes along dimension in decimal form
n_high = storage_height/box_height;

% round down to integer
n_high = floor(n_high);

% Calculate n_total
n_total = n_long*n_wide*n_high;

% Report results
disp('The maximum number of boxes is:')
disp(n_total)
