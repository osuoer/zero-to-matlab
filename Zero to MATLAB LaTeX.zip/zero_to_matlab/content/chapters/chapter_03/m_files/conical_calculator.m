% conical_calculator.m
% This script calculates the volume of water in a 
% conical tank given in section 3.2 of Zero to MATLAB.

% preamble
clear all;
clc;

% define height 
H = 2  % meters

% calculate r 
r = (1/3)*H   % meters

% calculate the volume using the formula
V_water = pi*(H/3)^3 % cubic meters

% user defined height
H = input('Input the height of the water (meters):')

% formatted output
disp('Volume of Water (cubic meters):')
disp(V_water)
