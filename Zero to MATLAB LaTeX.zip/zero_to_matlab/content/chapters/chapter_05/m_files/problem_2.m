% Studio 04A
% Problem 2
clear all; clc; close all; format compact;

% define T
% T = 325;
T = 275;

if T > 300
    disp('Too Hot!')
end
