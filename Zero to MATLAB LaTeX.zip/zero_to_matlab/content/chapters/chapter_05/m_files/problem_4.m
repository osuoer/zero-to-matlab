% Studio 04B
% Problem 3
clear all; clc; close all; format compact;

% random data
x = rand(1,10)

% for loop
for idx = 1:length(x)
    
    % if x is less than 0.25 or greater than 0.75
    if x(idx) > 0.25 && x(idx) < 0.75
        x(idx) = 0;
    end
    
end

disp(x)