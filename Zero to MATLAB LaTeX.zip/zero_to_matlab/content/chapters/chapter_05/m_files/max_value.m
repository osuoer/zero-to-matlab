% max_value.m

% This script finds the maximum value
% of the elements in an array.

% preamble
clear all; clc;

% define array
x = [1 5 3 7 42 11 2 12 16 6];

% initialize max_value
max_value = 0;

% loop through elements
for i = 1:length(x)

	% if element is greater than max_value
	if x(i) > max_value

		% assign element value to max_value
		max_value = x(i);
	
	% end if-statement
	end

% end for-loop
end

% report results
disp('Array values:')
disp(x)
disp('Maximum value:')
disp(max_value)
