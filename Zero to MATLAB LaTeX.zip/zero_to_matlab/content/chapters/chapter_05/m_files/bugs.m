clear all;  close all; clc;

x = [0:0.1:3]
n_cells = 1;
y=[];

for i = 1:length(x)
    
    if n_cells < 10000
        n_cells = n_cells*2;
    else
        n_cells = n_cells*0.5;
    end
    
    y(i) = n_cells;
end

plot(x,y)
        

