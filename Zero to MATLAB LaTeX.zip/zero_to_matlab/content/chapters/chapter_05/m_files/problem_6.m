% Studio 04B
% Problem 5
clear all; clc; close all; format compact;

% independent varible array
x = [0:0.001:25];

% for loop for calculation
for idx = 1:length(x)
    
    y(idx) = (sin(x(idx))^2)/x(idx);
    
end

plot(x,y)
title('Bounce Problem')
xlabel('x-axis')
ylabel('y-axis')