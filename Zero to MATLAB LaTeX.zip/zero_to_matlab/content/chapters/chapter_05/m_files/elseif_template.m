if a < b
    a + b
elseif a == b
    (a + b)^2
else
    a - b
end


a = 4
b = 3

if a < 10
    a + b
elseif a < 5
    (a + b)^2
else
    a - b
end