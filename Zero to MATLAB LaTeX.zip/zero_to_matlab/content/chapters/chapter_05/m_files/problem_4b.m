% Studio 04A
% Problem 4b
clear all; clc; close all; format compact;

% define x
% x = -12;
x = 0;
% x = 12;

if x < 0
    disp('Negative!')
else
    disp('Not Negative!')
end
