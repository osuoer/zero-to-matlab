% Studio 04B
% Problem 5
clear all; clc; close all; format compact;

% random data
x = rand


% if x is less than 0.25 or greater than 0.75
if x >= 0 && x < 0.2
    disp('Tiny')
elseif x >= 0.2 && x < 0.4
    disp('Small')
elseif x >= 0.4 && x < 0.6
    disp('Midpoint')
elseif x >= 0.6 && x < 0.8
    disp('Large')    
else
    disp('Huge')  
end
    
