if 1
    % code 
    % more code
end

if 0
    % code
    % more code
    
end

if a < b
    % code
    % more code 
end