% This script checks a temperature
% and returns a message based on
% the value.

% preamble
clear all; clc;

% define T
T = 325;

% check the condition
% and print message
if T > 300
    disp('Too Hot!')
else
    disp('Just right!')
end
