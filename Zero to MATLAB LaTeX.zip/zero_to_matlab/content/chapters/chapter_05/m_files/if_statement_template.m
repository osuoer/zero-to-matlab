if 1
    % code 
    % more code
end

if 0
    % code
    % more code   
end

if a < b
    % code
    % more code 
end

% This script demonstrates the basic
% functionality of an if-statement
clear all; close all; clc;

a = 3;
b = 7;

if a < b
    a + b
end

if a < b
    a + b
else
    a - b
end


