% find_max_value.m

% This script finds the maximum value
% of the elements in an array.

% preamble
clear all; clc;

% define array
A = [1, 4, 76, 42, 12];

% initialize max_value
max_value = A(1);

% loop through elements
for i = 2:length(A)

	% if element is greater than max_value
	if A(i) > max_value

		% assign element value to max_value
		max_value = A(i);
	
	% end if-statement
	end

% end for-loop
end

% report results
disp('Array values:')
disp(A)
disp('Maximum value:')
disp(max_value)
