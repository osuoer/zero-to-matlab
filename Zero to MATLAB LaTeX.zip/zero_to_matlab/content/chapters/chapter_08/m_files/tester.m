function y = tester(x)

y = b*x

end