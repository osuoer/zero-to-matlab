close all

% rectangle 1
x = [2,1,1,2];
y = [1,1,2,2];
fill(x,y,'k')
hold on;
line([1,2],[2.2,2.2],'Color', 'red')
line([1,1],[2.25,2],'Color', 'red','LineStyle','--')
line([2,2],[2.25,2],'Color', 'red','LineStyle','--')
h = text(1.3,2.3,'1.5 cm')

line([0.7,0.7],[2,1],'Color', 'red')
line([1,0.65],[1,1],'Color', 'red','LineStyle','--')
line([1,0.65],[2,2],'Color', 'red','LineStyle','--')
h = text(0.55,1.3,'1.5 cm')
set(h,'Rotation',90)

% triangle 1
x = [1.25,1.5,1.75];
y = [1,1.8,1];
fill(x,y,'w')

line([1.25,1.75],[0.8,0.8],'Color', 'red')
line([1.25,1.25],[0.8,1],'Color', 'red','LineStyle','--')
line([1.75,1.75],[0.8,1],'Color', 'red','LineStyle','--')
h = text(1.35,0.7,'0.5 cm')
line([1.5,1.5],[1,1.8],'Color', 'red')
line([1.45,1.55],[1,1],'Color', 'red')
line([1.45,1.55],[1.8,1.8],'Color', 'red')
% line([2.7,2.7],[1.9,2.05],'Color', 'red','LineStyle','--')
h = text(1.55,1.1,'0.8 cm')
set(h,'Rotation',90)
% h = text(2.2,2.1,'1.05 cm')

axis([0.5 2.5 0.5 2.5])
axis square
set(gca,'YTickLabel',[]);
set(gca,'XTickLabel',[]);

print('-dpng','-r1500','shape_problem_1.png')