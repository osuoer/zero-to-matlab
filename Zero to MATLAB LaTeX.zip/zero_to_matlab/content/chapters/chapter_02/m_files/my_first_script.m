% This is my first MATLAB script.

% make a variable
x = 7;  

% make another variable
y = 5;

% use the variables in a calculation
z = x*y

