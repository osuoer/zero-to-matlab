% This script evaluates the ideal gas law.

% Universal Gas Constant
R = 8.314   % (J/(mol K))

% Amount of substance
n = 1   % (mol)

% Volume
V = 0.001  % (m^3)

% Temperature
T = 315.15   % (K)

% Pressure calculation
P = (n*R*T)/V  % Pa