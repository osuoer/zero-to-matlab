% This script calculates the area
% of the part given in Figure 2.9.

% Calculate area of the square.
L = 1.5; % cm
W = 1.5; % cm
A_square = L*W; % cm^2;

% Calculate the area of the triangle.
B = 1.05; % cm
H = 0.9;  % cm
A_triangle = 0.5 * B * H;

% Calculate the area of the circle.
R = 0.3; % cm
A_circle = pi*(R^2);

% Calculate total area of the shape.
A_total = A_square + A_triangle - A_circle
