close all;


% rectangle 1
x = [2,1,1,2];
y = [1,1,2,2];
fill(x,y,'k')
hold on;
line([1,2],[2.2,2.2],'Color', 'red')
line([1,1],[2.25,2],'Color', 'red','LineStyle','--')
line([2,2],[2.25,2],'Color', 'red','LineStyle','--')
h = text(1.3,2.3,'1.5 cm')

line([0.7,0.7],[2,1],'Color', 'red')
line([1,0.65],[1,1],'Color', 'red','LineStyle','--')
line([1,0.65],[2,2],'Color', 'red','LineStyle','--')
h = text(0.55,1.3,'1.5 cm')
set(h,'Rotation',90)

% triangle 1
x = [2.7,2,2];
y = [1.9,1.3,1.9];
fill(x,y,'k')

line([2.8,2.8],[1.3,1.9],'Color', 'red')
line([2,2.85],[1.3,1.3],'Color', 'red','LineStyle','--')
line([2.7,2.85],[1.9,1.9],'Color', 'red','LineStyle','--')

line([2,2.7],[2,2],'Color', 'red')
line([2,2],[1.95,2.05],'Color', 'red','LineStyle','--')
line([2.7,2.7],[1.9,2.05],'Color', 'red','LineStyle','--')
h = text(2.9,1.4,'0.9 cm')
set(h,'Rotation',90)
h = text(2.2,2.1,'1.05 cm')


% circle
r = (0:0.001:1)'*2*pi;
x = 0.2*cos(r) + 1.5;
y = 0.2*sin(r) + 1.5;
fill(x,y,'w')
line([1.3,1.7],[1.5,1.5],'Color', 'red')
line([1.3,1.3],[1.45,1.55],'Color', 'red')
line([1.7,1.7],[1.45,1.55],'Color', 'red')
h = text(1.35,1.45,'0.6 cm')

axis([0.5 3 0.5 3])
axis square
set(gca,'YTickLabel',[]);
set(gca,'XTickLabel',[]);

print('-dpng','-r1500','test_image.png')