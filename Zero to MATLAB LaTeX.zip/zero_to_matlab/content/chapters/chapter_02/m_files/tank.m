close all;




% triangle 1
x = [-1,0,1];
y = [3,0,3];
fill(x,y,([0,107,164]./255))

grid on
line([0,0],[0,4],'Color', 'black')
color1 = ([200,82,0]./255)
hold on
plot(1,3,'o','MarkerEdge',color1, 'MarkerFace',color1, 'MarkerSize', 8)
plot(0,0,'o','MarkerEdge',color1, 'MarkerFace',color1, 'MarkerSize', 8)
line([0,1],[0,3],'Color', color1)
% line([2.8,2.8],[1.3,1.9],'Color', 'red')
% line([2,2.85],[1.3,1.3],'Color', 'red','LineStyle','--')
% line([2.7,2.85],[1.9,1.9],'Color', 'red','LineStyle','--')
% 
% line([2,2.7],[2,2],'Color', 'red')
% line([2,2],[1.95,2.05],'Color', 'red','LineStyle','--')
% line([2.7,2.7],[1.9,2.05],'Color', 'red','LineStyle','--')
% h = text(2.9,1.4,'0.9 cm')
% set(h,'Rotation',90)
% h = text(2.2,2.1,'1.05 cm')



axis([-2,2,0,4])
axis square
% set(gca,'YTickLabel',[]);
% set(gca,'XTickLabel',[]);

print('-dpng','-r1500','~/Documents/zero_to_matlab/01_root/chapters/chapter_03/img/cone_with_dimensions.png')