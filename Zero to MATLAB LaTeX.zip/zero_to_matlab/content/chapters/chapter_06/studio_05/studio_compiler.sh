#!/bin/bash

# get the root file name
export root_file_name="$(find . -name 'CBEE*.tex')"

#report
echo 'Compiling...'
echo $root_file_name
echo '---------------'

# set solutions to True
sed -i "s/soln{0}/soln{1}/g" $root_file_name

# call pdflatex in batch mode
pdflatex --interaction=batchmode $root_file_name

# get root name from .tex file
name="${root_file_name%%.tex}"

# move the current .pdf file to *_SOLUTIONS.pdf
out_name=$name".pdf"
out_name_soln=$name"_SOLUTIONS.pdf"
mv $out_name $out_name_soln

# set solutions to False
sed -i "s/soln{1}/soln{0}/g" $root_file_name

# call pdflatex in batch mode
pdflatex --interaction=batchmode $root_file_name

# report
echo '---------------'
echo 'Complete!'
echo "Files Generated:"
echo $out_name
echo $out_name_soln
