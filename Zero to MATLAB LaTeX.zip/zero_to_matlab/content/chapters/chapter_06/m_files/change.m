% change.m
% counting change with fprintf
clear all; close all; format compact; clc;

% quarters
num_q = 3;
val_q = 0.25; %dollars

% dimes
num_d = 4;
val_d = 0.10; % dollars

% nickels
num_n = 4;
val_n = 0.05 % dollars

% pennies
num_p = 3;
val_p = 0.01;

for q = 0:num_q 
    for d = 0:num_d
        for n = 0:num_n
            for p = 0:num_p
                total = q*val_q + d*val_d + n*val_n + p*val_p;
                fprintf('%i quarters + %i dimes + %i nickles + %i pennies = $%.2f \n',q,d,n,p,total)
                pause(0.25)
            end
        end
    end
end
