% ideal_fprintf.m
% ideal gas law with fprintf
clear all; close all; format compact; clc;
% temperature
T = 400; % kelvin

% amount
n = 100; % mol

% gas constant
R = 8.314; % J/(mol*K)

% volume
V = 0.01;

% convert volume to liters for reporting
V_liters = V*1000;

% pressure calculation
P = (n*R*T)/V;

% convert pressure to mega pascals for reporting
P_mpa = P/(10^6);

% formatting line NOT PART OF ASSIGNMENT
disp('---------------------------------')

% output a
fprintf('Pressure: %f Pascals \n',P)

% formatting line NOT PART OF ASSIGNMENT
disp('---------------------------------')

% output b
fprintf('The pressure created by %.1f mols of ideal gas in a %.4f liter container at %.2f K is: %.4f MPa\n',n,V_liters,T,P_mpa)