% mean with fprintf
clear all; close all; format compact; clc;
x = rand(1,10000);
total = 0;

for idx = 1:length(x)
    total = total + x(idx);
end

average = total/length(x);

fprintf('The average of the array is: %f \n', average)
    