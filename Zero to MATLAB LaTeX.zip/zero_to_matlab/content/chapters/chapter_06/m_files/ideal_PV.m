% ideal_isotherms.m
% This script plots the P-V curve
% using the ideal gas law.
clear all; close all; format compact; clc;

% define the temperature
T = 300; % (K)

% amount of gas
n = 1 % (mol)

% universal gas constant
R = 8.314 % (J/(mol*k))

% define volume array
V = [0.01:0.001:0.1]


% loop through volume
for i = 1:length(V)

	% calculate pressure
	P(i) = (n*R*T)/V(i)
end

% plot results
plot(V,P)
xlabel('Volume')
ylabel('Pressure')
