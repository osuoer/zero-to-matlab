% ideal_isotherms.m
% This script plots the isotherms of the ideal gas law
clear all; close all; format compact; clc;

% define the temperature array
T = [200:100:700] % kelvin

% amount of gas
n = 1 % mol

% universal gas constant
R = 8.314

% define volume array
V = [0.01:0.001:0.1]

% loop through temperature
for m = 1:length(T)

    % loop through volume
    for i = 1:length(V)

        % calculate pressure
        P(i) = (n*R*T(m))/V(i)
    end

    % plot inside the outer loop 
    % to capture each line
    plot(V,P)
    hold on
end

% format plot
xlabel('Volume')
ylabel('Pressure')
legend('100','200','300','400','500','600','700')
