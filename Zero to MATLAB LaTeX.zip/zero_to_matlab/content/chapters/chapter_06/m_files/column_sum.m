% column_sum.m
% This script calculates the sum of each column in 
% a 2D array and returns the values in a 1D array.
% The order of the columns is maintained.
clear all; close all; format compact; clc;

% make the data and display
data = rand(8,5)

% get the dimensions using the size command
[num_rows,num_cols] = size(data);

% intialize a row array of zeros
sum_of_columns = zeros(1,num_cols);

% loop through the columns
for col_idx = 1:num_cols
    % loop through the rows
    for row_idx = 1:num_rows
        
        % calculate the sum
        sum_of_columns(col_idx) = sum_of_columns(col_idx) + data(row_idx,col_idx);
    end
end

% report array
sum_of_columns