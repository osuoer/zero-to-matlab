% Temperature classification with fprintf
clear all; close all; format compact; clc;

% make the temperature array
T = 500*rand(1,10); % K

% loop and classify
for idx = 1:length(T)
  if T < 275
    fprintf('%d Kelvin is Too Cold!', T)
  elseif T >= 275 && T <= 300
    fprintf('%d Kelvin is Just Right!', T)
  else
    fprintf('%d Kelvin is Too Hot!', T)
  end
end
