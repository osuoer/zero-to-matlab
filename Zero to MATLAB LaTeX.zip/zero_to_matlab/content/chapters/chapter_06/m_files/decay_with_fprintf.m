% decay_with_fprintf.m
clear all; close all; format compact; clc;

% independent variable
t = [0:0.1:48];

% rate constant
k = 0.1; % 1/hr

% initial concentration
C_A0 = 10; % mg/L

% loop through time
for idx = 1:length(t)
    
    % calculate concentration
    C_A(idx) = C_A0*exp(-k*t(idx));
    
    % check for half life 
    if C_A(idx) < 0.51*C_A0 && C_A(idx) > 0.49*C_A0
        half_life = t(idx)
    end
    
end

plot(t,C_A)
title('Decay of species-A')
xlabel('Time (hrs)')
ylabel('Concentration (mg/L)')

fprintf('The halflife is: %f hours \n',half_life)

