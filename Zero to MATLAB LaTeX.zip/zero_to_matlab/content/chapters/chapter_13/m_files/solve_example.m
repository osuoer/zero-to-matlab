% define symbolic variables
syms a b c x

% define equation
eqn = a*x^2 + b*x + c == 0

% pass variables to solver
soln = solve(eqn)

