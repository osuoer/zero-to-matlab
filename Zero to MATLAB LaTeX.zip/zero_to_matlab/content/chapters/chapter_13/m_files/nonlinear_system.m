function F = nonlinear_system(vars)

% unpack variables
x = vars(1);
y = vars(2);
z = vars(3);

% define system
F(1) = 3*x*y - z  - 1; 
F(2) = 2*x - 2*y*z + 2;
F(3) = -exp(x) + 0.5*y - z;

end