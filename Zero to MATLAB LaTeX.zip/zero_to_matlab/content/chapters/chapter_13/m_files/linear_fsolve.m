% choose initial guess
x_init = 0;
y_init = 0;
z_init=0;

% pack guesses into array
vars_init = [x_init, y_init, z_init];

% call solver using function handle
% and initial values, save solution
% to a variable
soln = fsolve(@linear_system,vars_init);

% unpack solution to readable 
% variable names
x = soln(1)
y = soln(2)
z = soln(3)