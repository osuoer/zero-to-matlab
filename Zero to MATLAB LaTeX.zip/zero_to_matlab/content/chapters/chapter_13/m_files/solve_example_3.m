% define symbolic variables
syms a b c x

% define equation
eqn = a*x^2*exp(x) == 5

% pass variables to solver
soln = solve(eqn)

