syms a b c x
eqn = a*x^2 + b*x + c == -2

S = solve(eqn)

