function F = linear_system(vars)

% unpack variables
x = vars(1);
y = vars(2);
z = vars(3);

% define system
F(1) = 3*x + 2*y - z - 1; 
F(2) = 2*x - 2*y + 4*z + 2;
F(3) = -x + 0.5*y - z;

end