% line_marker_size.m
clear all; close all;

n = 11;

% data 1
x1 = linspace(0,5,n);
y1 = linspace(2,7,n) + sin(x1);

% data 1
x2 = linspace(0,5,n);
y2 = linspace(1.5,4,n) + sin(x2);

% define custom colors
custom_blue = [0,107,164]./255;
custom_orange = [255,128,14]./255;

% plot data with custom colors
plot(x1,y1,'-', 'Color', custom_blue, 'LineWidth', 2)
hold on;
plot(x2,y2,'-', 'Color', custom_orange, 'LineWidth', 2)

% scale axis
axis([-0.5,5.5,1,7.5])

legend('y_1','y_2')

% title('Custom Color Demo')
xlabel('x-axis')
ylabel('y-axis')

% save the figure 
saveas(gcf,'../img/custom_color_demo.png')