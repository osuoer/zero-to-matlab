clear all; close all; clc;

% make some data
n = 11;

x1 = linspace(0,10,n);
y1 = randn(1,n);

x2 = 0:0.1:3*pi;
y2 = sin(x2);

x3 = randn(1,n) + 16;
y3 = randn(1,n) + 9;
 
x4 = randn(1,n) + 18;
y4 = randn(1,n) + 12;


% default figure

% create 1x2 subplot and 
% activate the first axis
% for plotting
subplot(1,2,1)
plot(x1,y1)
xlabel('x-axis')
ylabel('y-axis')

% activate the second axis
% for plotting
subplot(1,2,2)
plot(x2,y2)
xlabel('x-axis')
ylabel('y-axis')


% custom figure

% specify name 
label = 'Suplots With Custom Figure Window';

% specify position in pixels
left = 200;
bottom = 200;
width = 800;
height = 400;
pos = [left bottom width height];

% make the figure
figure('Name', label, 'Position', pos);

% create 1x2 subplot and 
% activate the first axis
% for plotting
subplot(1,2,1)
plot(x1,y1)
xlabel('x-axis')
ylabel('y-axis')

% activate the second axis
% for plotting
subplot(1,2,2)
plot(x2,y2)
xlabel('x-axis')
ylabel('y-axis')


% 3x1 suplots with custom figure

% specify name 
label = '3x1 Subplot Demo';

% specify position in pixels
left = 100;
bottom = 100;
width = 400;
height = 900;
pos = [left bottom width height];

% make the figure
figure('Name', label, 'Position', pos);

% create 3x1 subplot and 
% activate the first axis
% for plotting
subplot(3,1,1)
plot(x1,y1)
xlabel('x-axis')
ylabel('y-axis')
title('Noisy Line')

% activate the second axis
% for plotting
subplot(3,1,2)
plot(x2,y2)
xlabel('x-axis')
ylabel('y-axis')
title('Sine Wave')

% activate the third axis
% for plotting
subplot(3,1,3)
plot(x3,y3,'x')
hold on
plot(x4,y4,'o')
xlabel('x-axis')
ylabel('y-axis')
title('Scatter Plot')
legend('Group 1', 'Group 2')