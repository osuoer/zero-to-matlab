clear all; close all; clc;

% points per cluster
n = 11;


scale = 20;
% 
% x1 = randn(1,n) + 3;
% y1 = randn(1,n) + 3;
% 
% x2 = randn(1,n) + 5;
% y2 = randn(1,n) + 16;
% 
% x3 = randn(1,n) + 16;
% y3 = randn(1,n) + 9;

load annotation_data.mat

% plot data and assign variables
p1 = plot(x1,y1,'b+');
hold on; 
p2 = plot(x2,y2,'ko');
p3 = plot(x3,y3,'rd'); 

% annotate the plot

% arrow
x_arrow = [0.6,0.67];
y_arrow = [0.4,0.47];
label = 'Red Group';
annotation('textarrow',x_arrow,y_arrow,'String',label)

% text box
dimensions = [.2 .3 .17 .05];
text = 'Blue Group';
annotation('textbox',dimensions,'String',text)

% box
dimensions = [.25 .65 .2 .25];
annotation('rectangle',dimensions,'Color','red')


axis([0,scale,0,scale]);

xlabel('x-axis')
ylabel('y-axis')
% title('Legend Subset')

% save the figure 
saveas(gcf,'../img/annotation_demo.png')