% line_marker_size.m
clear all; close all;

% x-array
x = [0:0.1:5];

% y-arrays
y1 = sin(x);
y2 = sin(x+(pi/4));

% plot y1 with default width (0.5 pts)
plot(x,y1,'r-')
hold on;

% plot y1 with custom width (2 pts)
plot(x,y2,'b-', 'LineWidth', 2)

% legend
legend('LineWidth = 0.5 pts','LineWidth = 2 pts')

% axis
axis([-0.25,5.25,-1.1,1.1])

% save the figure 
saveas(gcf,'../img/line_width_demo.png')