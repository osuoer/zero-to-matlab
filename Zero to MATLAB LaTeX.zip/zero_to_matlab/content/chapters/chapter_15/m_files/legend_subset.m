clear all; close all; clc;

n = 11;

% data 1
x1 = linspace(0,5,n);
y1 = linspace(2,7,n) + rand(1,n);

% data 2
x2 = linspace(3,8,n);
y2 = linspace(2,7,n) + rand(1,n);

% data 3
x3 = linspace(5,10,n);
y3 = linspace(2,7,n) + rand(1,n);

% plot data and assign line 
% line objects to variables
p1 = plot(x1,y1,'b+');
hold on; 
p2 = plot(x2,y2,'ko');
p3 = plot(x3,y3,'rd');

% make the legend
lines = [p1,p3];
labels = {'Blue Plus','Red Diamond'};
legend(lines,labels);

axis([-0.5,10.5, 1.5,8.5]);

xlabel('x-axis')
ylabel('y-axis')
% title('Legend Subset')

% save the figure 
saveas(gcf,'../img/legend_subset_demo.png')