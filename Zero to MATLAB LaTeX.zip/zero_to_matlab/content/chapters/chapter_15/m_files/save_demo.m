% DO NOT RUN!

clear all; close all; clc;

n = 11;

x1 = randn(1,n) + 16;
y1 = randn(1,n) + 9;
 
x2 = randn(1,n) + 18;
y2 = randn(1,n) + 12;

% make the plot
plot(x1,y1,'x')
xlabel('x-axis')
ylabel('y-axis')
title('Scatter Plot')

% save the figure 
saveas(gcf,'demo_plot.png')

% save the figure to a specific folder (Windows)
saveas(gcf,'C:\Users\Adam\Documents\demo_plot.png')

% save the figure to a specific folder (Mac/Linux)
saveas(gcf,'~/Documents/zero_to_matlab/img/demo_plot.png')



% create figure and assign to variable
f = figure(1);

%make the plot
% <some code>

% save with figure object as input
saveas(f,'demo_plot.png')