% line_marker_size.m
clear all; close all;

n = 11;

% data 1
x1 = linspace(0,5,n);
y1 = linspace(2,7,n) + 2*rand(1,n);

% data 1
x2 = linspace(5,10,n);
y2 = linspace(2,7,n) + 2*rand(1,n);

% plot y with default marker size
plot(x1,y1,'b+')
hold on;

% plot y with custom marker size
plot(x2,y2,'r+', 'MarkerSize', 15)

axis([-0.5,10.5,1.5,10])

legend('MarkerSize = 6','MarkerSize = 15')

% save the figure 
saveas(gcf,'../img/marker_size_demo.png')