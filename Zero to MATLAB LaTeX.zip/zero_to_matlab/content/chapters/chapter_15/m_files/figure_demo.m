clear all; close all; clc;

n = 11;

x1 = linspace(0,10,n);
y1 = randn(1,n);

x2 = 0:0.1:3*pi;
y2 = sin(x2);

x3 = randn(1,n) + 16;
y3 = randn(1,n) + 9;

x4 = linspace(0,7,n); 
y4a = linspace(2,5,n); 
y4b = linspace(1,3,n); 

% create multiple figures

% figure 1
figure(1);
plot(x1,y1)
xlabel('x-axis')
ylabel('y-axis')

% figure 2
figure(2);
plot(x2,y2)
xlabel('x-axis')
ylabel('y-axis')

% modify figure 1
figure(1)
title('Noise')

% Customize figure name and position

% specify name 
label = 'Zero to MATLAB'

% specify position in pixels
left = 100;
bottom = 100;
width = 600;
height = 400;
pos = [left bottom width height];

% make the figure
figure('Name', label, 'Position', pos);

% make the figure without a number
figure('Name', label, 'NumberTitle', 'off', 'Position', pos);



