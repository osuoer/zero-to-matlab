% line_marker_size.m
clear all; close all;

% number of data points
n = 11;

% data 1
x1 = linspace(0,5,n);
y1 = linspace(3,4,n) + randn(1,n);

% plot y with custom marker color
plot(x1,y1,'-','LineWidth',2)

% find x-axis limits
x_scale = 0.1;
x_min = min(x1) - x_scale*max(x1);
x_max = max(x1) + x_scale*max(x1);

% find y-axis limits
y_scale = 0.1;
y_min = min(y1) - y_scale*max(y1);
y_max = max(y1) + y_scale*max(y1);

% pass limits to axis command
axis([x_min,x_max,y_min,y_max])




xlabel('x-axis')
ylabel('y-axis')
% title('Scaled Axis Demo')

% legend('MarkerSize = 6','MarkerSize = 15')

% save the figure 
saveas(gcf,'../img/scaled_axis_demo.png')