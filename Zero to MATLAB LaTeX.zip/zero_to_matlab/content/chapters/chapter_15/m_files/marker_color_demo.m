% line_marker_size.m
clear all; close all;

n = 11;

% data 1
x1 = randn(1,n) + 3;
y1 = randn(1,n) + 4;

% data 2
x2 = randn(1,n) + 7;
y2 = randn(1,n) + 6;

% define custom colors
custom_light_blue = [162,200,236]./255;
custom_light_orange = [255,188,121]./255;

% plot y with custom marker color
plot(x1,y1,'o','MarkerEdgeColor','k'...
      ,'MarkerFaceColor',custom_light_blue...
      ,'MarkerSize', 10)
hold on;

% plot y with custom marker color
plot(x2,y2,'d','MarkerEdgeColor','k'...
    ,'MarkerFaceColor',custom_light_orange...
    ,'MarkerSize', 10)

axis([0,10,0,10])
xlabel('x-axis')
ylabel('y-axis')
% title('Custom Marker Color')

% legend('MarkerSize = 6','MarkerSize = 15')

% save the figure 
saveas(gcf,'../img/marker_color_demo.png')