% This script utilizes the
% ideal_gas function to plot
% ideal gas law isotherms.
clear all; close all; clc;

% number of mols
n = 1;

% gas constant (J/(mol*K))
R = 8.314;

% volume (m^3)
V = [0.01:0.001:0.1];

% temperature (K)
T = [300:100:700];

% plot inside loop
for i = 1:length(T)
    
    % call function
	P = ideal_gas(n,R,T(i),V);
	plot(V,P)
	hold on;
    
    % create legend label cell array
    % with sprintf
    labels{i} = sprintf('T = %d K', T(i));
    
end

% format plot
title('Ideal Gas Law Isotherms')
xlabel('Volume (m^3)')
ylabel('Pressure (Pa)')

% make the legend
legend(labels)


saveas(gcf,'../img/legend_auto_label_demo.png')