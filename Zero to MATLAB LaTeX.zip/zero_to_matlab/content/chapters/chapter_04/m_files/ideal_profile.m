% This script calculates and plots 
% pressure vs. temperature using the 
% ideal gas law.

% temperature (K)
T = [175:10:375]

% univeral gas constant 
R = 8.314   %  J/(mol * K)

% amount 
n = 1 % mol

% tank volume 
V = 0.001  % m^3

%for loop
for idx = 1:21
    
  % pressure calculation
  P(idx) = (n*R*T(idx))/V  
  
% end loop
end

% plot results
plot(T,P)
title('Ideal Gas Law')
xlabel('Temperature (K)')
ylabel('Pressure (Pa)')






















