% my_first_for_loop.m

% This script utilizes a for-loop to calculate
% the sine of an angle over a specified domain
% and plots the results.

% preamble
clear all; close all; clc;

% angle (radians)
theta = [0:(pi/8):(2*pi)];

% loop through index
for idx = 1:17
    
    % calculate y
    y(idx) = sin(theta(idx));

% end the loop
end

% make the plot
plot(theta,y)
title('The Sine Function')
xlabel('theta (radians)')
ylabel('sin(theta)')
