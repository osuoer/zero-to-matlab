% for loop definition
for idx = 1:10
    
    % Calculate the  square root of the 
    % x-element and assign the value to the 
    % corresponding y-element.
    y(idx) = sqrt(x(idx))

% end for-loop
end 