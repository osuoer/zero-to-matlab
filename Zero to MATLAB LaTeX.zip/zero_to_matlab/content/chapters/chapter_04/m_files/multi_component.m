% This script plots the exponential decay function
% as given in exercise 4 of Studio 03B.
clear all; close all; clc;

% rate constant
k = 0.1;

% initial concentration
C_A0 = 10;
C_B0 = 0;

% time domain
t = [0:5:50];

% for loop
for idx = 1:length(t)
    CA(idx) = C_A0*exp(-k*t(idx));
    CB(idx) = C_A0 - CA(idx);
end

%plot
plot(t,CA)
hold on
plot(t,CB)
title('Multicomponent Reaction')
xlabel('Time (hr)')
ylabel('Concentration (mg/L)')
legend('Species-A','Species-B')