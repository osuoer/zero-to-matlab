% This script plots the exponential decay function
% as given in exercise 3 of Studio 03A.

% rate constant
k = 0.1

% initial concentration
C_0 = 10

% time domain
t = [0:5:50]

% for loop
for idx = 1:11
    C(idx) = C_0*exp(-k*t(idx))
end

%plot
plot(t,C)
title('Species A')
xlabel('Time (hr)')
ylabel('Concentration (mg/L)')

