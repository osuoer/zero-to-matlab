% bounce
close all; clear all;

x = linspace(-10*pi,(10*pi),100);
y = (sin(x).^2)./x;

plot(x,y)