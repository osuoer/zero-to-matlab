% Preamble
%  This script plots the sin function for 
%  three different wave numbers.
clear all; close all;  clc;

% Generate independent variable array
% % Add some resolution with the
% % double colon operator. 
t = [0:0.1:10*pi];  %(ms)

k1 = 1/2;
k2 = 1;
k3 = 2;

% Loop to calculate elements in dependent
% variable array from elements in 
% independent variable array

loop_size = length(t);

for idx = 1:loop_size
    
    y1(idx) = sin(k1 * t(idx));
    y2(idx) = sin(k2 * t(idx));
    y3(idx) = sin(k3 * t(idx));
end
    
for idx = 1:loop_size    
    
    a = t(idx);
    y1(idx) = sin(k1 * a);
    y2(idx) = sin(k2 * a);   
    y2(idx) = sin(k3 * a);
        
end

% Input arrays into plot function 
plot(t,y1)
hold on
plot(t,y2)
plot(t,y3)

% Let's add a title
title('Wave Number Demo')

% And label the axes
xlabel('time (ms)')
ylabel('Amplitude')

% Now a legend
% We need to give it the names
% in the order they were plotted.
legend('k1 = 1/2','k2 = 1', 'k3 = 2')



% Preamble
%  This script plots the sin function
clear all; close all; format compact; clc;

% Generate independent variable array
% % Add some resolution with the
% % double colon operator. 
t = [0:0.1:10*pi]; %(ms)

k1 = 1/2;
k2 = 1;
k3 = 2;

f = 0.018;

% Loop to calculate elements in dependent
% variable array from elements in 
% independent variable array

loop_size = length(t);

for idx = 1:loop_size
    
    y1(idx) = sin(k1 * t(idx)) * f * t(idx);
    y2(idx) = sin(k2 * t(idx)) * f * t(idx);
    y3(idx) = sin(k3 * t(idx)) * f * t(idx);

end

% Input arrays into plot function 
plot(t,y1)
hold on
plot(t,y2)
plot(t,y3)

% Let's add a title
title('Wave Number Demo')

% And label the axes
xlabel('time (ms)')
ylabel('Amplitude')
axis([0, (10*pi), -0.6, 0.6])

% Now a legend
% We need to give it the names
% in the order they were plotted.
legend('k1 = 1/2','k2 = 1', 'k3 = 2')

% Turn on the grid
grid on




