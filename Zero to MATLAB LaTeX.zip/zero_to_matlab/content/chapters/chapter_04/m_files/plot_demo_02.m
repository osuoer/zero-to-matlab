% wave_demo.m
% This script plots the sin function

% preamble
clear all; close all; clc;

% Generate independent variable array
x = [0:10];


% Loop to calculate elements in dependent
% variable array from elements in 
% independent variable array

for idx = 1:11
    y(idx) = sin(x(idx));
end
for idx = 1:11
    
    % get value from x array
    a = x(idx); 
    
    % pass it to sin() function
    % and store value in y-array
    y(idx) = sin(a); 
    
end
% Input arrays into plot function 
plot(x,y)

% Let's add a title
title('Sin(x)')

% And label the axes
xlabel('x-axis')
ylabel('y-axis')


% Preamble
% This script plots the sin function
clear all; close all; format compact; clc; 

% Generate independent variable array
% Add some resolution with the
% double colon operator.  
x = [0:0.1:10];


% Loop to calculate elements in dependent
% variable array from elements in 
% independent variable array

for idx = 1:101
    
    y(idx) = sin(x(idx));

end

% Input arrays into plot function 
plot(x,y)

% Let's add a title
title('Sin(x)')

% And label the axes
xlabel('x-axis')
ylabel('y-axis')


% Preamble
%  This script plots the sin function
clear all; close all; format compact; clc;

% Generate independent variable array
% Add some resolution with the
% double colon operator.  
x = [0:0.1:10];


% Loop to calculate elements in dependent
% variable array from elements in 
% independent variable array

% Define a variable called "loop_size"
% and assign it the value of the output
% from the length function applied to 
% the x-array.
loop_size = length(x);

for idx = 1:loop_size
    
    y(idx) = sin(x(idx));
     
end

% Input arrays into plot function 
plot(x,y)

% Let's add a title
title('Sin(x)')

% And label the axes
xlabel('x-axis')
ylabel('y-axis')


% Preamble
%  This script plots the sin function
clear all; close all; format compact; clc;

% Generate independent variable array
% Add some resolution with the
% double colon operator. 
x = [0:0.1:10];


% Loop to calculate elements in dependent
% variable array from elements in 
% independent variable array

% Define a variable called "loop_size"
% and assign it the value of the output
% from the length function applied to 
% the x-array.
loop_size = length(x);

for idx = 1:loop_size
    
    y1(idx) = sin(x(idx));
    y2(idx) = cos(x(idx));   
    
end

% Input arrays into plot function 
plot(x,y1)
hold on
plot(x,y2)

% Let's add a title
title('Trigonometry')

% And label the axes
xlabel('x-axis')
ylabel('y-axis')

% Now a legend
% We need to give it the names
% in the order they were plotted.
legend('sin(x)','cos(x)')

