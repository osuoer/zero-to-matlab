function d_dt = fed_batch(t,components, F,S_0)
% function to calculate the value of the 
% derivative at each time step in the fed-batch
% simulation.

% Input variables
% - t          : time 
% - components : array of system components
% - F          : Flowrate of feed stream
% - S_0        : Substrate concentration in feed stream

% unpack components for readable variable names
V = components(1);
X = components(2);
S = components(3);

% define constants
mu_max = 0.2;  % (1/hr) maximum specific growth rate
Ks = 1;        % (g/L)  half max constant
Y_xs = 0.5;    % (g/g)  fractional yield of X from S

% calculate mu
mu = mu_max*S/(Ks + S);

% dV/dt
d_dt(1) = F;

% dX/dt
d_dt(2) = (mu - (F/V))*X;

% dS/dt 
d_dt(3) = (F/V)*(S_0 - S) - (1/Y_xs)*mu*X;

% transpose to column
d_dt = d_dt';
end