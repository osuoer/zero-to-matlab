% This script calls the ode45 solver to solve
% a multicomponent reaction problem

% preamble
clear all; close all; clc;

% define time span
tspan = [0,6];

% define initial concentration
% in column array
c_init = [10;    % Species A
           0;    % Species B
           0];   % Species C
       
% define rate constants
k1 = 1.5;
k2 = 1;

% call ode45
[t,c] = ode45(@(t,c) multicomponent(t,c,k1,k2), tspan, c_init);

% plot results
plot(t,c(:,1))
hold on;
plot(t,c(:,2))
plot(t,c(:,3))

% format plot
title('Multicomponent Reaction')
xlabel('Time')
ylabel('Concentration')
legend('C_A','C_B','C_C')


