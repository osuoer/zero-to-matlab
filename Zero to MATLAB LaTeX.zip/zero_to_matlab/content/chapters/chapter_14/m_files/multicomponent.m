function dcdt = multicomponent(t,c)
% This function returns the derivative 
% of a multicomponent reaction problem.

% define rate constants
k1 = 1.5;
k2 = 1;

% calcutate the derivative and
% store it as a vertical array
dcdt = [-k1*c(1);
         k1*c(1) - k2*c(2);
         k2*c(2)];
 
end