function dydt = predator_prey(t,y)
% This function returns the derivative
% of a Lotka-Volterra model.

% Lotka-Volterra constants

% fish growth constant
A = 0.2;

% fish death constant
B = 0.12;

% shark growth constant
C = 0.025;

% shark death constant
D = 0.1;

% unpack variables for readability
fish = y(1);
shark = y(2);

% calculate derivatives
dfish_dt = A*fish - B*fish*shark;
dshark_dt = C*fish*shark - D*shark;

%pack derivatives into column vector
dydt = [dfish_dt; 
       dshark_dt];

end


