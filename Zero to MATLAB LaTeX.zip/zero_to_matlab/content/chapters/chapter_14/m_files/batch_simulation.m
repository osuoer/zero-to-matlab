% This script uses ode15s to solve
% the a batch reactor problem with 
% a single substrate.

% Required custom functions
% (1) batch.m - calculates the derivative of the
%               ODE system at a given time.

% Operating Instructions
% 1) Define initial values of the components vector (line 28).
% 2) Define time span for simulation (line 32).
% 3) Verify that fed_batch.m is in the current directory.
% 4) Press "Run" or F5 to execute the script.
% 5) Modify kinetic and transport parameters in 
%    fed_batch.m as needed.


% Preamble
clear all; close all; clc;

% Define the initial values
% The elements of this column vector must be 
% in the same order as the column vector of 
% derivatives in the function.  In other words, 
% if dX/dt is the first element in the derivative
% vector, then X_init needs to be the first value
% in the initial value vector.
components_initial = [0.5;  % X (g/L)
                      100]; % S (g/L)

% Define the time span
tspan = [0,24]; % (hr)                  
                  
                  
% Call ode15s
% Pass the function callback, the time span, 
% and the initial values to the solver. Return
% a vector of time points and a 2D array with 
% columns containing the values of the components
% at each time point.
[t,components] = ode15s(@batch,tspan,components_initial);

% Plot results
plot(t,components(:,1),'linewidth',2) % X curve
hold on
plot(t,components(:,2),'linewidth',2) % S curve

% Format plot
title('Cell Growth with Monod Kinetics')
xlabel('Time')
ylabel('Mass (g/L)')
legend('Cells','Substrate')