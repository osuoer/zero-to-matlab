% This script uses ode15s to simulate
% a fed-batch reactor.

% Required custom functions

% - fed_batch.m 

% Operating Instructions

% 1) Define initial values of the components vector (line 49).
% 3) Define the flowrate of the nutrient feed. (line 27)
% 4) Verify that fed_batch.m is in the current directory.
% 5) Press "Run" or F5 to execute the script.
% 6) Modify kinetic and transport parameters in 
%    fed_batch.m or fed_batch_simulation.m as needed.


%---------------------------------------------------------
%---------------------------------------------------------
% Preamble
clear all; close all; clc;
%---------------------------------------------------------
%---------------------------------------------------------
% Define system parameters and initial values

% Flowrate
F = 10;    % (L/hr)

% Initial substrate concentration 
S_0 = 20;  % (g/L)

% Reactor volume
V_max = 500;  % (L)

% Initial fill volume
V_init = 100; % (L)

% Max fill time
t_max = (V_max - V_init)/F; % (hr)

% Define the initial values
% The elements of this column vector must be 
% in the same order as the column vector of 
% derivatives in the function.  In other words, 
% if dX/dt is the first element in the derivative
% vector, then X_init needs to be the first value
% in the initial value vector.
components_initial = [V_init;  % V (L)
                           2;  % X (g/L)
                           0]; % S (g/L)

% Define the time span
tspan = [0,t_max]; % (hr)
%---------------------------------------------------------
%---------------------------------------------------------
% Call ode15s
% Pass the function handle, the time span, 
% and the initial values to the solver. Return
% a vector of time points and a 2D array with 
% columns containing the values of the components
% at each time point.
[t,components] = ode15s(@(t,components) fed_batch(t,components,F,S_0),tspan,components_initial);

%---------------------------------------------------------
% Print results
X_final = components(end,2);

disp('-------------------------------------')
fprintf('Final X (g/L): %.2f\n',X_final)
disp('-------------------------------------')

%---------------------------------------------------------
% Plot results

% Type "doc figure" in the command window
% to read about the Position option and 
% change the size/location of the figure.
figure('Position',[200,150,600,800])

% Unpack variables for easy plotting
V_curve = components(:,1);
X_curve = components(:,2);
S_curve = components(:,3);

% Create subplots for grouped visualization

% subplot for concentration
subplot(3,1,1)                        %3x1 subplot, first axis
plot(t,X_curve,'linewidth',2) % X curve
hold on
plot(t,S_curve,'linewidth',2) % S curve
title('Concentration')
xlabel('Time (hr)')
ylabel('grams/Liter')
legend('Cells','Substrate')

% subplot for reactor volume
subplot(3,1,2)                   % 3x1 subplot, second axis
plot(t,V_curve,'linewidth',2)    % V curve
title('Reactor Volume')
xlabel('Time (hr)')
ylabel('Liters')

% subplot for total mass
subplot(3,1,3)     % 3x1 subplot, third axis

% calculate total mass (volume*concentration)
X_tot = V_curve.*X_curve;
S_tot = V_curve.*S_curve;

plot(t,X_tot,'linewidth',2)
hold on;
plot(t,S_tot,'linewidth',2)
title('Total Mass')
xlabel('Time (hr)')
ylabel('grams')
legend('Cells','Substrate')
%---------------------------------------------------------
%---------------------------------------------------------


