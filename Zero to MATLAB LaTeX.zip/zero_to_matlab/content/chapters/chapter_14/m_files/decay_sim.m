% This script calls the ode45 solver
% to solve the exponential decay equation.

% preamble
clear all; close all; clc;

% define time span
tspan = [0,50];

% define initial value
y_init = 10;

% call solver
[t,y] = ode45(@decay, tspan, y_init);

% plot results
plot(t,y)
ylabel('y-axis')
xlabel('x-axis')
