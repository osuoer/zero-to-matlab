function dydt = decay(t,y)
% This function returns the derivative
% the exponential decay function at
% a given time step.

% define rate constant
k = 0.1;

% calculate derivative
dydt = -k*y;

end