% This script uses ode15s to run a 
% predator-prey simulation using
% the Lotka-Volterra equations.
clear all; close all; clc;

% define the time span
tspan = [0,250];

% define the initial number of
% predators and prey
y_init = [10;  %fish
          5];  %sharks

% call ode15s
[t,y] = ode15s(@predator_prey,tspan,y_init);

% plot results
plot(t,y(:,1))
hold on
plot(t,y(:,2))

% format plot
title('Lotka-Volterra Model')
xlabel('Time')
ylabel('Population')
legend('Fish','Sharks')


