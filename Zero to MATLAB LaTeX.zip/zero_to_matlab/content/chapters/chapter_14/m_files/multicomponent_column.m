function dcdt = multicomponent(t,c)
% This function returns the derivative 
% of a multicomponent reaction problem.

% define rate constants
k1 = 1.5;
k2 = 1;

% calcutate the derivatives and 
% store each value with an index

% species A
dcdt(1) = -k1*c(1);

% species B
dcdt(2) = k1*c(1) - k2*c(2);

% species C
dcdt(3) = k2*c(2)

% transpose to vertical array
dcdt = dcdt';

end