function dydt = predator_prey_test(t,y)
% This function returns the derivative
% of a Lotka-Volterra model.

% Lotka-Volterra constants

% fish growth constant
A = 0.02;

% fish death constant
B = 0.012;

% shark growth constant
C = 0.0025;

% shark death constant
D = 0.01;

% unpack variables for readability
fish = y(1);
shark = y(2);

% calculate derivatives
dfish_dt = A*fish - B*fish*shark;
dshark_dt = C*fish*shark - D*shark;

%pack derivatives into column vector
dydt = [dfish_dt; 
       dshark_dt];

end


