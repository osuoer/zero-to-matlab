function d_dt = batch(t,components)
% This function returns the 
% derivative of a Cell-Substrate
% system using Monod Kinetics.

% get components from column vector
X = components(1);
S = components(2);

% define constants
Ks = 1;       % g/l
mu_max = 0.2; % 1/hr
Y_xs = 0.5;   % g/g

mu = ((mu_max*S)/(Ks + S));

% calculate derivative
d_dt(1) = mu * X;          % X equation
d_dt(2) = -(mu * X)/Y_xs;  % S equation


% transpose returns a column vecotr
d_dt = d_dt';
end